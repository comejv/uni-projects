#include <string.h>
#include "client.h"

int array_max_index(int *array, int size)
{
    int max = 0;
    int max_index = 0;
    for (int i = 0; i < size; i++)
        if (array[i] > max)
        {
            max = array[i];
            max_index = i;
        }
    return max_index;
}

int subtring_in_string(char *string, char *substring)
{
    int substring_length = strlen(substring);
    int string_length = strlen(string);
    for (int i = 0; i < string_length - substring_length; i++)
        if (strncmp(substring, string + i, substring_length) == 0)
            return 1;
    return 0;
}

char *token(char *reponse)
{
    const char *separator = " ,.!?\"\n";
    const char *u_alpha_v = "AEIOUY";
    const char *l_alpha_v = "aeiouy";
    const char *u_alpha_c = "BCDFGHJKLMNPQRSTVWXZ";
    const char *l_alpha_c = "bcdfghjklmnpqrstvwxz";
    const char *num = "0123456789";
    const char *spec = "@#$%^&*~_+=[]{}|;:/<>\\";

    const char *faux_pos = "messages";

    char *mots[50];
    int prob[50] = {0};
    int i = 0;

    // Séparation des mots et calcul du score
    mots[i] = strtok(reponse, separator);
    while (mots[i] != NULL)
    {
        int len = strlen(mots[i]);
        if (strstr(faux_pos, mots[i]) || len < 5)
        {
            i++;
            mots[i] = strtok(NULL, separator);
            continue;
        }
        for (int j = 0; j < len; j++)
        {
            if (strchr(l_alpha_v, mots[i][j]))
                prob[i] += 4;
            else if (strchr(l_alpha_c, mots[i][j]))
                prob[i] += 8;
            else if (strchr(u_alpha_v, mots[i][j]))
                prob[i] += 15;
            else if (strchr(u_alpha_c, mots[i][j]))
                prob[i] += 18;
            else if (strchr(num, mots[i][j]))
                prob[i] += 50;
            else if (strchr(spec, mots[i][j]))
                prob[i] += 50;
        }
        i++;
        mots[i] = strtok(NULL, separator);
    }

    return mots[array_max_index(prob, i)];
}

int main(int argc, char const *argv[])
{
    char reponse[1000];  // pour stocker la réponse du serveur
    char reponse2[1000]; // pour stocker une copie de la réponse du serveur
    char token1[20];

    // Affiche les échanges avec le serveur (false pour désactiver)
    mode_debug(1);

    connexion("im2ag-appolab.u-ga.fr", 443);
    envoyer_recevoir("login 12114562 VINCENT", reponse);

    envoyer_recevoir("load leGateau", reponse);
    envoyer_recevoir("start", reponse);

    strcpy(reponse2, reponse);

    strcpy(token1, token(reponse2));
    envoyer_recevoir(token1, reponse);
    strcpy(reponse2, reponse);

    // Début
    while (!subtring_in_string(reponse, "You found the cake!"))
    {
        envoyer_recevoir(token(reponse2), reponse);
        strcpy(reponse2, reponse);
    }
    // Recommencer
    envoyer_recevoir(token1, reponse);
    strcpy(reponse2, reponse);

    // Tout le reste
    while (!subtring_in_string(reponse, "You found the cake!"))
    {
        envoyer_recevoir(token(reponse2), reponse);
        strcpy(reponse2, reponse);
    }


    return 0;
}
