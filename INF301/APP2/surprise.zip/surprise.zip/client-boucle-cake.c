#include "client.h"
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>

#define MAXMSG MAXREP

void page_detec(char *reponse, int* i){
    unsigned long l;
    int space,b;
    
    b=0;
    l=0;
    space=0;
    while (l+3<strlen(reponse))
    {
        if (reponse[l+1]=='a' && reponse[l+2]=='g' && reponse[l+3]=='e' && (reponse[l]=='p' || reponse[l]=='P')){
            if (reponse[l+5]=='i' && reponse[l+6]=='s'){
                *i=l+8;
            }else{
                *i=l+5;
            }
            if (reponse[l+5]!='n' || reponse[l+6]!='u' || reponse[l+7]!='m' || reponse[l+8]!='b' || reponse[l+9]!='e' || reponse[l+10]!='r'){
                b=1;
            }
        }
        if (reponse[l]==' '){
            space++;
        }
        l++;
    }
    if (space == 0){
        *i=0;
        return;
    }
    if(b==0){
        *i=-1;
    }
    return;
}

int main() {
    char reponse[MAXREP]; // pour stocker la réponse du serveur
    char message[MAXMSG]; // pour stocker le message à envoyer au serveur
    char temp[MAXMSG];
    //int i,j;
    //int b;

    // Affiche les échanges avec le serveur (false pour désactiver)
    mode_debug(true);

    // Connexion au serveur AppoLab
    connexion("im2ag-appolab.u-ga.fr", 9999);
    // utilisez le port 443 en cas de problème sur le 9999
    /* connexion("im2ag-appolab.u-ga.fr", 443); */

    // Remplacez <identifiant> et <mot de passe> ci dessous.
    envoyer_recevoir("login 12119967 GUILLAUME", reponse);
    envoyer_recevoir("load leGateau", reponse);
    // Notez qu'ici on n'utilise pas la reponse du serveur

    envoyer_recevoir("start", reponse);
    strcpy(temp,reponse);

    while (reponse[strlen(reponse)-2] >= '0' && reponse[strlen(reponse)-2] <= '9'){
        envoyer_recevoir(&reponse[strlen(reponse)-6], reponse);
    }
    reponse[strlen(reponse)-14]='\0';
    envoyer_recevoir(&reponse[strlen(reponse)-5], reponse);
    envoyer_recevoir(&temp[strlen(temp)-6],reponse);
    while (reponse[strlen(reponse)-2] >= '0' && reponse[strlen(reponse)-2] <= '9'){
        envoyer_recevoir(&reponse[strlen(reponse)-6], reponse);
    }
    /*
    reponse[strlen(reponse)-14]='\0';
    envoyer_recevoir(&reponse[strlen(reponse)-6], reponse);
    for (j=0; j<401; j++){
        i=strlen(reponse)-2;
        if (i=='.'){
            i--;
        }
        while (reponse[i] != ' '){
            i--;
        }
        i++;
        envoyer_recevoir(&reponse[i], reponse);
    }
    b=1;
    while (b){
        i=-1;
        page_detec(reponse,&i);
        if(i!=-1){
            j=i;
            while(reponse[j] != ' ' && reponse[j] != '.' && reponse[j] != ',' && reponse[j] != '!' && reponse[j] != '"'){
                j++;
            }
            reponse[j]='\0';
            envoyer_recevoir(&reponse[i], reponse);
        }else{
            i=strlen(reponse)-2;
            if (i=='.'){
                reponse[i]='\0';
                i--;
            }
            while (reponse[i] != ' '){
                i--;
            }
            i++;
            if (reponse[i]=='w' && reponse[i+1]=='h' && reponse[i+2]=='y'){
                i=0;
                j=i;
                while(reponse[j] != ' ' && reponse[j] != '.' && reponse[j] != ',' && reponse[j] != '!' && reponse[j] != '"'){
                j++;
            }
            reponse[j]='\0';
            }
            envoyer_recevoir(&reponse[i], reponse);
        }
    }*/

    while(1==1){
        lire_clavier(message);   // message tapé au clavier
        envoyer_recevoir(message, reponse); // on envoie message, et on reçoit la réponse du serveur
    }

    printf ("Réponse du serveur: %s", reponse );

    printf ("Fin de la connection au serveur\n");
    return 0;
}
